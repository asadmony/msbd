@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('common.proposals.parts.proposalsGroup')
@endsection


@push('js')
@endpush

