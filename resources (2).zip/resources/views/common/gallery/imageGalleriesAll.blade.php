@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('common.gallery.parts.imageGalleriesAll')
@endsection


@push('js')


@endpush
