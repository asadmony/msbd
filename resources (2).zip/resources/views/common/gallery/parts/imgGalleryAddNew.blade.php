    <section class="content-header">
      <h1>
        New Gallery
        <small>Create</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-plus"></i> New Gallery</a></li>
        <li class="active">create</li>
      </ol>
    </section>

    <section class="content">

    @include('common.gallery.includes.forms.imgGalleryAddNewForm')

</section>

