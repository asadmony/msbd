    <section class="content-header">
      <h1>
        Update 
        <small>Gallery</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-plus"></i> Update </a></li>
        <li class="active">Gallery</li>
      </ol>
    </section>

    <section class="content">

    @include('common.gallery.includes.forms.imgGalleryEditForm')

</section>

