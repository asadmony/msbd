@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('common.gallery.parts.videoGalleriesAll')
@endsection


@push('js')


@endpush
