@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('common.gallery.parts.videoGalleryAddNew')
@endsection


@push('js')


<script type="text/javascript">

</script>

@endpush
