
     <!-- Classic Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
        <div class="modal-dialog w3-animate-zoom" role="document">
          <div class="box box-widget">
            {{-- <div class="box-body" style="min-height: 300px;">       --}}
            <div id="modalFeed">





              <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Report about <span class="badge badge-default w3-large">  </span></h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="material-icons">clear</i>
                    </button>
                </div>
                <div class="modal-body">


 

                     
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>
                </div>
            </div>









            </div>       
            {{-- </div> --}}
       <div class="overlay modal-feed-overlay" style="display: none;">
       <i class="fa-circle-o-notch fa fa-spin w3-xxxlarge text-red"></i>
       </div>
     </div>
        </div>
    </div>
    <!--  End Modal -->



  <!-- Modal -->
{{--   <div class="modal" data-backdrop="false" id="myModal" role="dialog">
    <div class="modal-dialog w3-animate-zoom">
     <div class="box box-widget">
      <div id="modalFeed">

      <form class="form-horizontal">
      <!-- Modal content-->
      <div class="modal-content w3-round">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Write Something About this</h4>
        </div>

        <div class="modal-body" style="height: 250px;">




        </div>

        <div class="modal-footer">
          <button type="reset" class="btn btn-default" data-dismiss="modal">Cancel</button>

          <button type="submit" class="btn btn-success pull-right">Submit</button>
        </div>
      </div>
      </form>





      </div>
       <div class="overlay modal-feed" style="display: none;">
       <i class="ion-load-c fa fa-spin w3-xxxlarge text-green"></i>
       </div>
     </div>
    </div>
  </div> --}}