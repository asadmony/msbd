<div class="row">
  <div class="col-sm-12">
    <div class="w3-card-2 w3-round">
      

 

    <div class="box box-widget">
            <div class="box-header w3-panel w3-leftbar w3-border-purple">
              <h3 class="box-title">
                 Our Facebook Page
              </h3>
            </div>
            <div class="box-body w3-topbar">





              
        @include('welcome.includes.others.fbPageArea')



              

              
               
            </div>
          </div>
              
 
              </div>
            </div>
          </div>

          <br>



 

 