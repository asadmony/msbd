<div role="main" class="main shop py-4">
    <div class="container">
        <div class="row">
            @include('theme.prt.checkout.parts.forIndivisual')
        </div>
    </div>
</div>