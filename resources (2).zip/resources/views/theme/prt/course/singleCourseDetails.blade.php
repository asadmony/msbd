@extends('theme.prt.layouts.prtMaster')

@section('contents')
@include('theme.prt.course.parts.singleCourse')
@endsection