@extends('admin.layouts.adminMaster')
@section('title', 'Dhaka Metro News')

@push('css')
@endpush

@section('content')

  @include('admin.parts.userSettingList')

@endsection


@push('js')
@endpush
