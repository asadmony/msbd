@extends('admin.layouts.adminMaster')
@section('title', 'Bangali Muslim Marriage')

@push('css')
@endpush

@section('content')
  @include('admin.membership.parts.membershipPackageEdit')
@endsection


@push('js')
 
@endpush

