<template>
    <div class="padding-around">
        <div class="h1">Ecommerce Dashboard</div>
    </div>
</template>