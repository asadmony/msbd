<template>
    <div>
        <section class="padding-top">
        <h5 class="title-section padding-x">Orders</h5>
        <nav class="nav-list">
            <a class="btn-list" href="#">
                <span class="float-right badge badge-warning">3</span>
                <span class="text">On proccess</span>
            </a>
            <a class="btn-list" href="#">
                <span class="float-right badge badge-success">1</span>
                <span class="text">Shipped</span>
            </a>
            <a class="btn-list" href="#"> 
                <span class="float-right badge badge-secondary">0</span>
                <small class="title"></small>
                <span class="text">Unpaid</span>
            </a>
        </nav>
        </section>
    </div>
</template>