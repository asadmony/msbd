@extends('theme.prt.layouts.prtMaster')

@section('contents')
@include('theme.prt.include.home')
@endsection