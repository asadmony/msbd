<div class="fb-page"
  data-href="https://www.facebook.com/secondlifebd1" 
  data-width="300"
  data-height="410"
  data-hide-cover="false"
  data-tabs="timeline,messages"
  data-show-facepile="true"></div>