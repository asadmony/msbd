
<br> <br>
  <div class="main main-raised" style="background: #eee;">
    <div class="profile-content ">
        <div class="container ">
    <div class="row">
        <div class="col-sm-12">

              <br>  

  


    <div class="page-content" style="min-height: 500px;">

    	 			<div class="row">
 				<div class="col-sm-6 offset-sm-3">
 	
 	<div class="box box-widget">
 		<div class="box-header with-border">
 			<h3 class="box-title">Pay to bKash, Rocket or Bank and submit the form below</h3>
 		</div>
 		<div class="box-body">

 					@include('user.payments.includes.forms.payNowEditForm')
 

 			


 		</div>
 	</div>

 </div>
</div>


    </div>
            

 
 

</div>
</div>
</div>
        </div>
    </div>
