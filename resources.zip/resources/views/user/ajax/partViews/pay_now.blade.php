<div class="box box-widget mb-0 w3-animate-zoom" style="min-height: 600px;">

    <div class="box-header with-border">
        <h3 class="box-title"><i class="fa fa-credit-card"></i> Upgrade Account / Pay Now </h3>
    </div>

    <div class="box-body">
    		<h4>Pay to bKash, Rocket or Bank and submit the form below</h4>

    	<div class="w3-border w3-border-purple w3-padding w3-round">

    		
            @include('user.payments.includes.forms.payNowForm')
    	</div>
 
    </div>              	

  </div>