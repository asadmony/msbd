@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('common.media.parts.mediaAll')
@endsection


@push('js')
@endpush
