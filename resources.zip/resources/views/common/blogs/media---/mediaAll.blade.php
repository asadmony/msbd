@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('admin.blogs.media.parts.mediaAll')
@endsection


@push('js')
@endpush
