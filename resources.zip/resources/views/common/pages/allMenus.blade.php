@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')

  @include('common.pages.parts.allMenus')

@endsection


@push('js')
@endpush
