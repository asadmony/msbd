    <section class="content-header">
      <h1>
        Page
        <small>Update</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-plus"></i> Page</a></li>
        <li class="active">Update</li>
      </ol>
    </section>

     <section class="content">

     @include('common.pages.includes.forms.pageEditForm')


     </section>

