@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('common.users.parts.usersAll')
@endsection


@push('js')
<script type="text/javascript">


</script>
@endpush

