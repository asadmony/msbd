@extends('mobile.layout.base')
@section('body')
<div class="container">
	<h4 class="text-center">Coming Soon!</h4>
</div>
@endsection