@extends('mobile.layout.base')
@section('body')
<div class="container">
    <h3>Complete your Profile</h3>
    {{-- @include('user.parts.createProfileForm') --}}
    @include('user.parts.createProfileForm2')
</div>
@endsection