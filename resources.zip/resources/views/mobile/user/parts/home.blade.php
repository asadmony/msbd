{{-- @include('mobile.user.includes.userProgressCard') --}}
@include('mobile.user.includes.newProfiles')
@include('mobile.user.includes.myMatch')
@include('mobile.user.includes.myVisitors')
@include('mobile.user.includes.myFavourites')
