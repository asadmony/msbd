<template>
    <div>
        <hr class="divider mb-3">

        <h5 class="title-section">Recently viewed</h5>

        <section class="scroll-horizontal padding-x">
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
        </section>
    </div>
</template>