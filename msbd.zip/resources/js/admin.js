require('./global.js');
require('admin-lte');