<template>
    <div>
                
        <hr class="divider my-3">


        <h5 class="title-section">Best deals</h5>
        <section class="scroll-horizontal  padding-x">
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
            <product-item></product-item>
        </section> 
    </div>
</template>