    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Home</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" style="min-height: 700px;">

      <div class="row">
        <div class="col-sm-12">

          <div class="panel panel-default">
            <div class="panel-heading">Media Person's Dashboard</div>

            <div class="panel-body">
              

            </div>
          </div>

        </div>
      </div>
      

    </section>
    <!-- /.content -->