@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')
  @include('common.blogs.categories.parts.categoryAddNew')
@endsection


@push('js')
@endpush
