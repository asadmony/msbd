<section class="content-header">
<h1>
    User
    <small>New</small>
</h1>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> User</a></li>
    <li class="active">New</li>
</ol>
</section>
<!-- Main content -->
<section class="content">
<!-- Info boxes -->
<div class="row">
    <div class="col-md-12">
        @include('alerts.alerts')
		
		@include('common.users.includes.newUserForm')

	</div>
</div>
<!-- /.row -->


</section>