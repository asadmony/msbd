@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')

  @include('common.payments.parts.paymentHistoryForUser')

@endsection


@push('js')
 

@endpush
