<div class="w3-card-2">
  
<div class="box box-widget mb-3 w3-animate-zoom w3-hover-shadow">
    <div class="box-body" style="min-height: 200px;">

      User Statistics Card

    </div>
</div>
</div>