<div class="w3-card-2">
  
<div class="box box-widget mb-3 w3-animate-zoom w3-hover-shadow">
    {{-- <div class="box-body" style="min-height: 450px;"> --}}

      <a href="">
      	
      <img class="img-fluid" src="{{ asset('img/timelinead.gif') }}" alt="msbd">
      </a>

    {{-- </div> --}}
</div>
</div>