<a target="_blank" href="{{ asset($photo->img_url) }}">
    <img class="img-responsive img-thumbnail" src="{{ asset($photo->img_url) }}" style="max-height: 150px;margin-top: 5px;margin-right: 5px;" alt="Bangali Muslim Marriage">
</a>
    