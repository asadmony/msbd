@extends('theme.prt.layouts.prtMaster')

@section('contents')
@include('theme.prt.package.parts.singlePackage')
@endsection