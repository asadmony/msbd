@extends('theme.prt.layouts.prtMaster')
@section('contents')
@include('theme.prt.checkout.parts.checkoutCompanyDetails')
@endsection