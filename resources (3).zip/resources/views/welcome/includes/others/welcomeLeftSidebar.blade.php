<div class="w3-card-2">
<div class="box box-widget">
  <div class="box-body" style="min-height: 200px;">
     W L Sidebar will be here
  </div>
</div>
</div>

 
@include('welcome.includes.others.fbPageAreaContainer')

@include('welcome.includes.others.ourVisitorContainer')

 