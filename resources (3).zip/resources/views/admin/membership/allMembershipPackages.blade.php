@extends('admin.layouts.adminMaster')
@section('title', 'Bangali Muslim Marriage')

@push('css')
@endpush

@section('content')
  @include('admin.membership.parts.allMembershipPackages')
@endsection


@push('js')
 
@endpush

