@extends('admin.layouts.adminMaster')
@section('title', 'Bangali Muslim Marriage')

@push('css')
@endpush

@section('content')
  @include('admin.membership.parts.membershipPackageAddNew')
@endsection


@push('js')
 
@endpush

