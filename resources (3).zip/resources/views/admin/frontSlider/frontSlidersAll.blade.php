@extends('admin.layouts.adminMaster')
@section('title', 'Bangali Muslim Marriage')

@push('css')
@endpush

@section('content')

  @include('admin.frontSlider.parts.frontSlidersAll')

@endsection


@push('js')
@endpush
