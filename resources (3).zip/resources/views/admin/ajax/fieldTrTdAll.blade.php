<td width="50">{{$field->id}}</td>
    <td width="450">{{$field->title}}</td>
    <td>
      {{-- <a class="btn btn-xs btn-warning btn-amb-type-edit" href="javascript::void(0)">Edit</a> --}}
      {{-- <div class="btn-group btn-group-xs">
        
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><i class="fa fa-trash"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-right" role="menu">                        

          <li class="w3-padding"><a class="w3-btn w3-red w3-small w3-round w3-hover-red btn-cat-delete" href="{{route('admin.ambulanceTypeDelete',$field)}}" data-url="">Confirm</a></li>
        </ul>
      </div> --}}


    </td>