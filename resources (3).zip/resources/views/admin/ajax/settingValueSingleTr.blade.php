<tr class="table-cat">
    @include('admin.ajax.settingValueSingleTrTdAll')
  </tr>